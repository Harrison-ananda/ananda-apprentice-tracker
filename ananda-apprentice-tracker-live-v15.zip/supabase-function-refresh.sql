create or replace function public.create_apprentice_staff(input_name text)
returns table (
  id uuid,
  name text,
  start_date date,
  mentor text,
  current_level text,
  share_token text,
  created_at timestamptz,
  updated_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_staff() then
    raise exception 'Staff access required';
  end if;

  return query
  insert into public.apprentices (name)
  values (trim(input_name))
  returning
    apprentices.id,
    apprentices.name,
    apprentices.start_date,
    apprentices.mentor,
    apprentices.current_level,
    apprentices.share_token,
    apprentices.created_at,
    apprentices.updated_at;
end;
$$;

create or replace function public.save_task_progress(
  input_apprentice_id uuid,
  input_task_key text,
  input_complete boolean,
  input_completed_on date,
  input_taught_by text,
  input_method text,
  input_notes text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_staff() then
    raise exception 'Staff access required';
  end if;

  insert into public.task_progress (
    apprentice_id,
    task_key,
    complete,
    completed_on,
    taught_by,
    method,
    notes,
    updated_at
  )
  values (
    input_apprentice_id,
    input_task_key,
    input_complete,
    input_completed_on,
    input_taught_by,
    input_method,
    input_notes,
    now()
  )
  on conflict (apprentice_id, task_key) do update
  set
    complete = excluded.complete,
    completed_on = excluded.completed_on,
    taught_by = excluded.taught_by,
    method = excluded.method,
    notes = excluded.notes,
    updated_at = now();
end;
$$;

create or replace function public.get_apprentice_by_token(token text)
returns table (
  id uuid,
  name text,
  start_date date,
  mentor text,
  current_level text
)
language sql
stable
security definer
set search_path = public
as $$
  select a.id, a.name, a.start_date, a.mentor, a.current_level
  from public.apprentices a
  where a.share_token = token;
$$;

create or replace function public.get_progress_by_token(token text)
returns table (
  task_key text,
  complete boolean,
  completed_on date,
  taught_by text,
  method text,
  notes text
)
language sql
stable
security definer
set search_path = public
as $$
  select p.task_key, p.complete, p.completed_on, p.taught_by, p.method, p.notes
  from public.task_progress p
  join public.apprentices a on a.id = p.apprentice_id
  where a.share_token = token;
$$;

create or replace function public.get_questions_by_token(token text)
returns table (
  id uuid,
  question_date date,
  body text,
  status text,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = public
as $$
  select q.id, q.question_date, q.body, q.status, q.created_at
  from public.apprentice_questions q
  join public.apprentices a on a.id = q.apprentice_id
  where a.share_token = token
  order by q.created_at desc;
$$;

create or replace function public.get_staff_task_progress()
returns table (
  apprentice_id uuid,
  task_key text,
  complete boolean,
  completed_on date,
  taught_by text,
  method text,
  notes text
)
language sql
stable
security definer
set search_path = public
as $$
  select p.apprentice_id, p.task_key, p.complete, p.completed_on, p.taught_by, p.method, p.notes
  from public.task_progress p
  where public.is_staff();
$$;

grant execute on function public.create_apprentice_staff(text) to authenticated;
grant execute on function public.save_task_progress(uuid, text, boolean, date, text, text, text) to authenticated;
grant execute on function public.get_staff_task_progress() to authenticated;
grant execute on function public.get_apprentice_by_token(text) to anon, authenticated;
grant execute on function public.get_progress_by_token(text) to anon, authenticated;
grant execute on function public.get_questions_by_token(text) to anon, authenticated;

notify pgrst, 'reload schema';
