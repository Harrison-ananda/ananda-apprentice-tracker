-- ananda apprentice growth tracker
-- Run this in Supabase SQL Editor for the live version.

create extension if not exists pgcrypto;

create table if not exists public.staff_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.apprentices (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  start_date date,
  mentor text,
  current_level text not null default 'level-1',
  share_token text not null unique default encode(gen_random_bytes(32), 'hex'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.task_progress (
  apprentice_id uuid not null references public.apprentices(id) on delete cascade,
  task_key text not null,
  complete boolean not null default false,
  completed_on date,
  taught_by text,
  method text,
  notes text,
  updated_at timestamptz not null default now(),
  primary key (apprentice_id, task_key)
);

create table if not exists public.apprentice_questions (
  id uuid primary key default gen_random_uuid(),
  apprentice_id uuid not null references public.apprentices(id) on delete cascade,
  question_date date not null default current_date,
  body text not null default '',
  status text not null default 'Open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.staff_notes (
  id uuid primary key default gen_random_uuid(),
  apprentice_id uuid not null references public.apprentices(id) on delete cascade,
  note_date date not null default current_date,
  body text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'FAQ',
  body text not null default '',
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.staff_users
    where user_id = auth.uid()
  );
$$;

alter table public.staff_users enable row level security;
alter table public.apprentices enable row level security;
alter table public.task_progress enable row level security;
alter table public.apprentice_questions enable row level security;
alter table public.staff_notes enable row level security;
alter table public.resources enable row level security;

drop policy if exists "staff can read staff users" on public.staff_users;
drop policy if exists "staff can manage apprentices" on public.apprentices;
drop policy if exists "staff can manage task progress" on public.task_progress;
drop policy if exists "staff can manage apprentice questions" on public.apprentice_questions;
drop policy if exists "staff can manage staff notes" on public.staff_notes;
drop policy if exists "staff can manage resources" on public.resources;
drop policy if exists "anyone can read resources" on public.resources;

create policy "staff can read staff users"
on public.staff_users for select
using (public.is_staff());

create policy "staff can manage apprentices"
on public.apprentices for all
using (public.is_staff())
with check (public.is_staff());

create policy "staff can manage task progress"
on public.task_progress for all
using (public.is_staff())
with check (public.is_staff());

create policy "staff can manage apprentice questions"
on public.apprentice_questions for all
using (public.is_staff())
with check (public.is_staff());

create policy "staff can manage staff notes"
on public.staff_notes for all
using (public.is_staff())
with check (public.is_staff());

create policy "staff can manage resources"
on public.resources for all
using (public.is_staff())
with check (public.is_staff());

create policy "anyone can read resources"
on public.resources for select
using (true);

create or replace function public.get_apprentice_by_token(token text)
returns table (
  id uuid,
  name text,
  start_date date,
  mentor text,
  current_level text
)
language sql
stable
security definer
set search_path = public
as $$
  select a.id, a.name, a.start_date, a.mentor, a.current_level
  from public.apprentices a
  where a.share_token = token;
$$;

create or replace function public.get_progress_by_token(token text)
returns table (
  task_key text,
  complete boolean,
  completed_on date,
  taught_by text,
  method text,
  notes text
)
language sql
stable
security definer
set search_path = public
as $$
  select p.task_key, p.complete, p.completed_on, p.taught_by, p.method, p.notes
  from public.task_progress p
  join public.apprentices a on a.id = p.apprentice_id
  where a.share_token = token;
$$;

create or replace function public.get_questions_by_token(token text)
returns table (
  id uuid,
  question_date date,
  body text,
  status text,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = public
as $$
  select q.id, q.question_date, q.body, q.status, q.created_at
  from public.apprentice_questions q
  join public.apprentices a on a.id = q.apprentice_id
  where a.share_token = token
  order by q.created_at desc;
$$;

create or replace function public.add_question_by_token(token text, question_body text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  apprentice uuid;
  new_question uuid;
begin
  select id into apprentice
  from public.apprentices
  where share_token = token;

  if apprentice is null then
    raise exception 'Invalid apprentice link';
  end if;

  insert into public.apprentice_questions (apprentice_id, body)
  values (apprentice, question_body)
  returning id into new_question;

  return new_question;
end;
$$;

insert into public.resources (title, category, body, sort_order)
values
  ('Program overview', 'Expectations', 'Apprentices are a huge asset to ananda hair studio and are future stylists. The program is built to help apprentices grow their eye, hand, and heart through education, salon support, observing mentors, and model days.', 10),
  ('Objective', 'Expectations', 'The goal is to guide apprentices toward a professional hairstylist career through elevated education and support, while helping assess current strengths and areas for growth.', 20),
  ('Shift types', 'Shift types', 'Apprentice shifts include salon assistant shifts, shadow days, and model days. Each type has a different focus, but all require professionalism, awareness, and contribution to the salon.', 30),
  ('Break rules', 'Policies', 'Use the full PDF for the current break policy. Staff can update this resource as the policy is finalized.', 40)
on conflict do nothing;
